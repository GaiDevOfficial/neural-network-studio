NEURAL NETWORK STUDIO - WINDOWS PORTABLE BUILD
================================================

1. Keep this whole folder together.
2. Double-click NeuralNetworkStudio.exe.
3. No installer, Python, Node.js or external runtime is required.

The app serves its own pages from a local-only server and stores data on this
machine. Nothing is uploaded by the desktop host.

WHY A FOLDER INSTEAD OF ONE EXE?
PyInstaller's self-extracting one-file launcher triggers a Windows Defender
machine-learning false positive (Trojan:Win32/Bearfoos.A!ml). This folder build
is the same application without that one-file wrapper, and it does not trigger
the same detection. Distribute this folder, or a ZIP of it, rather than the old
single-file build.

IF WINDOWS SMARTSCREEN WARNS
This build is not code-signed with a commercial certificate, so Windows may show
"Windows protected your PC" the first time. That is a reputation warning, not a
virus detection. Only run a copy you received from the publisher, and verify the
SHA-256 checksum supplied with the ZIP.

For a fully trusted, warning-free public release, sign NeuralNetworkStudio.exe
with a trusted code-signing certificate. That is the only way to remove the
unsigned-app reputation warning on other people's machines.
